

int add_i(int a, int b) {
    return(a+b);
}

int sub_i(int a, int b) {
    return(a-b);
}

int mul_i(int a, int b) {
    return(a*b);
}

int div_i(int a, int b) {
    return(a/b);
}
